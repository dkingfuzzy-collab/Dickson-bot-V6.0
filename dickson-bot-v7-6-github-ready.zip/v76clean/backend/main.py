import os
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException, Request, Response, Depends
from fastapi.middleware.cors import CORSMiddleware
from starlette.middleware.base import BaseHTTPMiddleware
from market_data.aggregator import CandleAggregator
from market_data.feed_manager import FeedManager
from analysis.mtf_engine import analyze_mtf
from analysis.poi import analyze_poi
from engine.confluence import ConfluenceEngine
from setup.generator import generate_setup
from paper.engine import Tracker, Setup, stats, profitability_estimate
from backtest import run_backtest
from auth import init_db, authenticate, create_session, get_user, revoke

app=FastAPI(title='Dickson Bot V7.6 Final Secure Paper Terminal')

allowed_origins=[x.strip() for x in os.getenv('ALLOWED_ORIGINS','http://localhost:8000').split(',') if x.strip()]
app.add_middleware(CORSMiddleware,allow_origins=allowed_origins,allow_methods=['GET','POST','OPTIONS'],allow_headers=['Content-Type'],allow_credentials=True)

class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request, call_next):
        response=await call_next(request)
        response.headers['X-Content-Type-Options']='nosniff'
        response.headers['X-Frame-Options']='DENY'
        response.headers['Referrer-Policy']='same-origin'
        response.headers['Permissions-Policy']='camera=(), microphone=(), geolocation=()'
        if os.getenv('COOKIE_SECURE','true').lower()=='true':
            response.headers['Strict-Transport-Security']='max-age=31536000; includeSubDomains'
        return response
app.add_middleware(SecurityHeadersMiddleware)
agg=CandleAggregator(); tracker=Tracker(); clients=set(); confluence=ConfluenceEngine()

def token_from_request(request:Request): return request.cookies.get('session')
def current_user(request:Request):
    u=get_user(token_from_request(request))
    if not u: raise HTTPException(401,'Authentication required')
    return u

@app.on_event('startup')
async def startup():
    init_db()
    if os.getenv('AUTO_START_FEEDS','false').lower()=='true': await feed.start()
@app.on_event('shutdown')
async def shutdown(): await feed.stop()

@app.get('/api/health')
def health(): return {'status':'ok','version':'V7.6','mode':'paper_only','authentication':'enabled','chart':'interactive','multibot':'enabled','database':'sqlite'}

@app.post('/api/dashboard/analyze')
def dashboard_analyze(payload:dict,user=Depends(current_user)):
    candles=payload.get('candles',[])
    atr=float(payload.get('atr',0.0))
    mtf=payload.get('mtf_context',{})
    c=confluence.evaluate(candles,atr,mtf)
    p=analyze_poi(payload.get('poi_candles',{}))
    return {'confluence':c,'poi':p,'mode':'paper_only'}
@app.post('/api/auth/login')
def login(payload:dict,response:Response):
    u=authenticate(payload.get('username',''),payload.get('password',''))
    if not u: raise HTTPException(401,'Invalid credentials')
    token=create_session(u['id']); response.set_cookie('session',token,httponly=True,samesite='lax',secure=os.getenv('COOKIE_SECURE','false').lower()=='true',max_age=86400,path='/')
    return {'authenticated':True,'username':u['username'],'role':u['role']}
@app.post('/api/auth/logout')
def logout(request:Request,response:Response):
    revoke(token_from_request(request)); response.delete_cookie('session',path='/'); return {'authenticated':False}
@app.get('/api/auth/me')
def me(user=Depends(current_user)): return {'authenticated':True,'username':user['username'],'role':user['role']}

async def broadcast(message):
    dead=[]
    for ws in clients:
        try: await ws.send_json(message)
        except Exception: dead.append(ws)
    for ws in dead: clients.discard(ws)
async def on_candle(symbol,candle): await broadcast({'type':'candle_completed','symbol':symbol,'candle':candle})
feed=FeedManager(agg,on_candle)

@app.get('/api/feed/status')
def feed_status(user=Depends(current_user)): return feed.snapshot()
@app.post('/api/feed/start')
async def feed_start(user=Depends(current_user)):
    if not feed.tasks: await feed.start()
    return feed.snapshot()
@app.post('/api/feed/stop')
async def feed_stop(user=Depends(current_user)): await feed.stop(); return feed.snapshot()
@app.websocket('/ws/market')
async def market_ws(ws:WebSocket):
    token=ws.cookies.get('session')
    if not get_user(token): await ws.close(code=1008); return
    await ws.accept(); clients.add(ws)
    try:
        await ws.send_json({'type':'feed_status','data':feed.snapshot()})
        while True: await ws.receive_text()
    except (WebSocketDisconnect,Exception): clients.discard(ws)

@app.post('/api/candle/tick')
def tick(x:dict,user=Depends(current_user)):
    return dict(zip(('completed','current'),agg.update(x['symbol'],float(x['price']),float(x['timestamp']))))
@app.get('/api/candles/{symbol}/{timeframe}')
def candles(symbol:str,timeframe:str,user=Depends(current_user)):
    return {'symbol':symbol,'timeframe':timeframe,'candles':agg.snapshot(symbol,timeframe),'mode':'paper_only'}
@app.post('/api/analysis/mtf')
def mtf(x:dict,user=Depends(current_user)): return analyze_mtf(x.get('symbol','UNKNOWN'),x.get('candles',{}))
@app.post('/api/analysis/poi')
def poi(x:dict,user=Depends(current_user)): return analyze_poi(x.get('candles',{}))
@app.post('/api/confluence/evaluate')
def confluence_evaluate(payload:dict,user=Depends(current_user)): return confluence.evaluate(payload.get('candles',[]),float(payload.get('atr',0.0)),payload.get('mtf_context',{}))
@app.post('/api/setup/generate')
def setup_generate(payload:dict,user=Depends(current_user)):
    c=confluence.evaluate(payload.get('candles',[]),float(payload.get('atr',0.0)),payload.get('mtf_context',{}))
    if not c['qualified'] or c['direction']=='NEUTRAL': return {'qualified':False,'confluence':c,'setup':None,'mode':'paper_only'}
    s=generate_setup(symbol=payload['symbol'],candles=payload['candles'],direction=c['direction'],score=c['score'],aligned_bots=c['aligned_bots'],qualified=c['qualified'],atr=float(payload.get('atr',0.0)),timeframe=payload.get('timeframe','15m'))
    s.reasons=[r.get('reason',r.get('direction','')) for r in c['bots'] if r.get('direction')==c['direction']]
    paper=Setup(setup_id=s.setup_id,symbol=s.symbol,direction=s.direction,entry=s.entry,sl=s.sl,tp1=s.tp1,tp2=s.tp2,tp3=s.tp3,score=s.score,timeframe=s.timeframe); tracker.add(paper)
    result=s.as_dict(); result['profitability_estimate']=profitability_estimate(tracker.items.values(),symbol=s.symbol,timeframe=s.timeframe,direction=s.direction,score=s.score); return {'qualified':True,'confluence':c,'setup':result,'mode':'paper_only'}
@app.post('/api/paper/setup')
def paper_setup(x:dict,user=Depends(current_user)): s=Setup(**x); tracker.add(s); return s.__dict__
@app.post('/api/paper/{setup_id}/price')
def paper_price(setup_id:str,x:dict,user=Depends(current_user)): return tracker.update(setup_id,float(x['price']))
@app.post('/api/paper/{setup_id}/taken')
def paper_taken(setup_id:str,x:dict,user=Depends(current_user)): return tracker.mark_taken(setup_id,bool(x.get('taken',True)))
@app.get('/api/paper/setups')
def paper_setups(user=Depends(current_user)): return tracker.all()
@app.get('/api/paper/statistics')
def paper_statistics(user=Depends(current_user)): return stats(tracker.items.values())
@app.get('/api/paper/analytics')
def paper_analytics(user=Depends(current_user)): return stats(tracker.items.values())
@app.post('/api/setup/profitability')
def setup_profitability(payload:dict,user=Depends(current_user)): return profitability_estimate(tracker.items.values(),symbol=payload.get('symbol'),timeframe=payload.get('timeframe'),direction=payload.get('direction'),score=payload.get('score'))
@app.post('/api/backtest/run')
def backtest_run(payload:dict,user=Depends(current_user)): return run_backtest(payload.get('symbol','UNKNOWN'),payload.get('candles',{}),int(payload.get('min_score',60)),int(payload.get('max_setups',500)))

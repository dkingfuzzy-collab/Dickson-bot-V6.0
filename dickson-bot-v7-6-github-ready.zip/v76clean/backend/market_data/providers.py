import os, json, asyncio
from typing import AsyncIterator
import websockets

TWELVE_WS = "wss://ws.twelvedata.com/v1/quotes/price"

async def twelve_data_stream(symbols: list[str]) -> AsyncIterator[dict]:
    key = os.getenv("TWELVE_DATA_API_KEY")
    if not key:
        raise RuntimeError("TWELVE_DATA_API_KEY is not configured")
    uri = f"{TWELVE_WS}?apikey={key}"
    async with websockets.connect(uri, ping_interval=20, ping_timeout=20) as ws:
        await ws.send(json.dumps({
            "action": "subscribe",
            "params": {"symbols": ",".join(symbols)}
        }))
        async for raw in ws:
            msg=json.loads(raw)
            if isinstance(msg,dict) and 'price' in msg and ('symbol' in msg or 'event' in msg):
                try:
                    yield {'provider':'twelve_data','symbol':msg.get('symbol'),'price':float(msg['price']),'timestamp':float(msg.get('timestamp') or __import__('time').time())}
                except (TypeError,ValueError):
                    continue

async def binance_btc_stream() -> AsyncIterator[dict]:
    # Public market-data stream; no account credentials and no order execution.
    uri = "wss://stream.binance.com:9443/ws/btcusdt@trade"
    async with websockets.connect(uri, ping_interval=20, ping_timeout=20) as ws:
        async for raw in ws:
            msg = json.loads(raw)
            yield {
                "provider": "binance",
                "symbol": "BTC/USDT",
                "price": float(msg["p"]),
                "timestamp": msg["T"]
            }


# Compatibility aliases used by older integration code.
BinancePublicFeed = binance_btc_stream
TwelveDataWebSocketFeed = twelve_data_stream

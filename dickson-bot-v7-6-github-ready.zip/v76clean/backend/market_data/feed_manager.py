import asyncio, os, time
from collections import defaultdict
from .providers import binance_btc_stream, twelve_data_stream

class FeedManager:
    def __init__(self, aggregator, on_candle=None):
        self.aggregator = aggregator
        self.on_candle = on_candle
        self.tasks = []
        self.last_ticks = {}
        self.status = defaultdict(lambda: 'STOPPED')

    async def _consume(self, name, stream):
        self.status[name] = 'CONNECTING'
        try:
            async for tick in stream:
                symbol = tick['symbol']; price = float(tick['price'])
                ts = float(tick.get('timestamp', time.time()))
                self.last_ticks[symbol] = {'price': price, 'timestamp': ts, 'provider': name}
                completed, current = self.aggregator.update(symbol, price, ts)
                if self.on_candle:
                    for candle in completed:
                        await self.on_candle(symbol, candle)
                self.status[name] = 'RUNNING'
        except asyncio.CancelledError:
            self.status[name] = 'STOPPED'
            raise
        except Exception as exc:
            self.status[name] = f'ERROR: {exc}'

    async def start(self, binance_symbols=None, twelve_symbols=None):
        binance_symbols = binance_symbols or ['btcusdt']
        twelve_symbols = twelve_symbols or ['XAU/USD','EUR/USD','GBP/USD']
        if binance_symbols:
            self.tasks.append(asyncio.create_task(self._consume('binance', binance_btc_stream())))
        if os.getenv('TWELVE_DATA_API_KEY') and twelve_symbols:
            self.tasks.append(asyncio.create_task(self._consume('twelve_data', twelve_data_stream(twelve_symbols))))

    async def stop(self):
        for task in self.tasks:
            task.cancel()
        if self.tasks:
            await asyncio.gather(*self.tasks, return_exceptions=True)
        self.tasks.clear()
        self.status.clear()

    def snapshot(self):
        return {
            'providers': dict(self.status),
            'last_ticks': self.last_ticks,
            'running_tasks': len(self.tasks),
        }

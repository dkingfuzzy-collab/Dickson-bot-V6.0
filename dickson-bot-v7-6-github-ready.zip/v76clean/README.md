# Dickson Bot V7.6 — Final Secure Paper Terminal

First complete release of the private paper/research terminal.

Includes:
- private authentication and server-side authorization
- SQLite persistence for paper setups and auth sessions
- interactive multi-timeframe chart
- 1M/15M/1H/4H/1D candle aggregation
- ICT/SMC context, structure, liquidity, FVG, displacement and Order Block/POI heuristics
- five-bot confluence dashboard
- setup generation with entry/SL/TP
- chronological research backtest
- historical paper profitability statistics with Wilson 95% interval
- PWA foundation
- Docker deployment configuration
- security headers and restricted CORS

This is a paper/simulation research system. It does not place live-money orders and its historical statistics are not guarantees of future performance.

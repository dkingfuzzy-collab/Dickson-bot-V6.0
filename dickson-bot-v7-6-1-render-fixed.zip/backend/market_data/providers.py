import os, json, asyncio, time, urllib.parse, urllib.request
from typing import AsyncIterator
import websockets

TWELVE_WS = "wss://ws.twelvedata.com/v1/quotes/price"
BINANCE_REST = "https://api.binance.com/api/v3/klines"

async def twelve_data_stream(symbols: list[str]) -> AsyncIterator[dict]:
    key = os.getenv("TWELVE_DATA_API_KEY")
    if not key:
        raise RuntimeError("TWELVE_DATA_API_KEY is not configured")
    uri = f"{TWELVE_WS}?apikey={key}"
    async with websockets.connect(uri, ping_interval=20, ping_timeout=20) as ws:
        await ws.send(json.dumps({"action":"subscribe","params":{"symbols":",".join(symbols)}}))
        async for raw in ws:
            msg=json.loads(raw)
            if isinstance(msg,dict) and 'price' in msg and ('symbol' in msg or 'event' in msg):
                try:
                    yield {'provider':'twelve_data','symbol':msg.get('symbol'),'price':float(msg['price']),'timestamp':float(msg.get('timestamp') or time.time())}
                except (TypeError,ValueError):
                    continue

async def binance_btc_stream() -> AsyncIterator[dict]:
    uri = "wss://stream.binance.com:9443/ws/btcusdt@trade"
    async with websockets.connect(uri, ping_interval=20, ping_timeout=20) as ws:
        async for raw in ws:
            msg = json.loads(raw)
            if 'p' not in msg: continue
            yield {"provider":"binance","symbol":"BTCUSD","price":float(msg["p"]),"timestamp":float(msg["T"])/1000.0}

def _binance_interval(tf):
    return {'1m':'1m','15m':'15m','1h':'1h','4h':'4h','1d':'1d'}[tf]

def _fetch_binance_sync(interval, limit=500):
    qs=urllib.parse.urlencode({'symbol':'BTCUSDT','interval':_binance_interval(interval),'limit':min(int(limit),1000)})
    req=urllib.request.Request(BINANCE_REST+'?'+qs,headers={'User-Agent':'DicksonPaperTerminal/7.6.1'})
    with urllib.request.urlopen(req,timeout=15) as resp:
        return json.loads(resp.read().decode('utf-8'))

async def binance_historical_candles(timeframe, limit=500):
    raw=await asyncio.to_thread(_fetch_binance_sync,timeframe,limit)
    rows=[]
    for k in raw:
        try:
            rows.append({'timestamp':int(k[0]/1000),'open':float(k[1]),'high':float(k[2]),'low':float(k[3]),'close':float(k[4])})
        except (TypeError,ValueError,IndexError):
            continue
    return rows

BinancePublicFeed = binance_btc_stream
TwelveDataWebSocketFeed = twelve_data_stream

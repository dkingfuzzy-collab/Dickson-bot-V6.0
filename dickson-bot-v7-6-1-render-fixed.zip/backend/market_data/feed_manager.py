import asyncio, os, time
from collections import defaultdict
from .providers import binance_btc_stream, twelve_data_stream, binance_historical_candles

class FeedManager:
    def __init__(self, aggregator, on_candle=None):
        self.aggregator=aggregator; self.on_candle=on_candle; self.tasks=[]
        self.last_ticks={}; self.status=defaultdict(lambda:'STOPPED'); self.bootstrap_status={}

    async def _consume(self,name,stream_factory):
        while True:
            self.status[name]='CONNECTING'
            try:
                async for tick in stream_factory():
                    symbol=tick['symbol']; price=float(tick['price']); ts=float(tick.get('timestamp',time.time()))
                    self.last_ticks[self.aggregator.normalize_symbol(symbol)]={'price':price,'timestamp':ts,'provider':name}
                    completed,_=self.aggregator.update(symbol,price,ts)
                    if self.on_candle:
                        for candle in completed: await self.on_candle(self.aggregator.normalize_symbol(symbol),candle)
                    self.status[name]='RUNNING'
            except asyncio.CancelledError:
                self.status[name]='STOPPED'; raise
            except Exception as exc:
                self.status[name]=f'ERROR: {exc}'
                await asyncio.sleep(5)

    async def bootstrap(self):
        self.bootstrap_status['BTCUSD']='LOADING'
        for tf in ('1m','15m','1h','4h','1d'):
            try:
                rows=await binance_historical_candles(tf,500)
                count=self.aggregator.seed_candles('BTCUSD',tf,rows)
                self.bootstrap_status[f'BTCUSD:{tf}']=f'{count} candles'
            except Exception as exc:
                self.bootstrap_status[f'BTCUSD:{tf}']=f'ERROR: {exc}'
        self.bootstrap_status['BTCUSD']= 'READY' if all('candles' in v for k,v in self.bootstrap_status.items() if k.startswith('BTCUSD:')) else 'PARTIAL'
        return dict(self.bootstrap_status)

    async def start(self,binance_symbols=None,twelve_symbols=None):
        if self.tasks: return
        await self.bootstrap()
        if (binance_symbols or ['btcusdt']):
            self.tasks.append(asyncio.create_task(self._consume('binance',binance_btc_stream)))
        twelve_symbols=twelve_symbols or ['XAU/USD','EUR/USD','GBP/USD']
        if os.getenv('TWELVE_DATA_API_KEY'):
            self.tasks.append(asyncio.create_task(self._consume('twelve_data',lambda: twelve_data_stream(twelve_symbols))))

    async def stop(self):
        for task in self.tasks: task.cancel()
        if self.tasks: await asyncio.gather(*self.tasks,return_exceptions=True)
        self.tasks.clear()
        self.status.clear()

    def snapshot(self):
        return {'providers':dict(self.status),'last_ticks':self.last_ticks,'running_tasks':len(self.tasks),'bootstrap':dict(self.bootstrap_status)}

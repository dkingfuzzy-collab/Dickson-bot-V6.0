from collections import defaultdict, deque

TIMEFRAME_SECONDS={"1m":60,"15m":900,"1h":3600,"4h":14400,"1d":86400}

SYMBOL_ALIASES={
    "BTC/USDT":"BTCUSD", "BTCUSDT":"BTCUSD", "BTCUSD":"BTCUSD",
    "XAU/USD":"XAUUSD", "XAUUSD":"XAUUSD",
    "XAG/USD":"XAGUSD", "XAGUSD":"XAGUSD",
    "EUR/USD":"EURUSD", "EURUSD":"EURUSD",
    "GBP/USD":"GBPUSD", "GBPUSD":"GBPUSD",
}

class CandleAggregator:
    def __init__(self,max_history=500):
        self.candles=defaultdict(dict)
        self.history=defaultdict(lambda: defaultdict(lambda: deque(maxlen=max_history)))
        self.max_history=max_history

    def normalize_symbol(self,symbol):
        raw=str(symbol or '').upper().replace(' ', '')
        return SYMBOL_ALIASES.get(raw, raw)

    def _bucket(self,ts,tf): return int(ts//TIMEFRAME_SECONDS[tf])*TIMEFRAME_SECONDS[tf]

    def update(self,symbol,price,ts):
        symbol=self.normalize_symbol(symbol)
        done=[]
        for tf in TIMEFRAME_SECONDS:
            start=self._bucket(ts,tf)
            c=self.candles[symbol].get(tf)
            if c is None or c["timestamp"]!=start:
                if c:
                    closed=c.copy(); self.history[symbol][tf].append(closed)
                    done.append({"timeframe":tf,"candle":closed})
                c={"timestamp":start,"open":price,"high":price,"low":price,"close":price}
                self.candles[symbol][tf]=c
            else:
                c["high"]=max(c["high"],price); c["low"]=min(c["low"],price); c["close"]=price
        return done

    def seed_candles(self,symbol,timeframe,rows):
        symbol=self.normalize_symbol(symbol)
        if timeframe not in TIMEFRAME_SECONDS: return 0
        q=self.history[symbol][timeframe]
        q.clear()
        clean=[]
        for r in rows:
            c={k:(int(r[k]) if k=='timestamp' else float(r[k])) for k in ('timestamp','open','high','low','close')}
            clean.append(c)
        clean=sorted(clean,key=lambda x:x['timestamp'])[-self.max_history:]
        # Treat the newest row as the current candle; older rows are closed history.
        if clean:
            for c in clean[:-1]: q.append(c)
            self.candles[symbol][timeframe]=clean[-1].copy()
        return len(clean)

    def snapshot(self,symbol,timeframe=None,include_current=True):
        symbol=self.normalize_symbol(symbol)
        if timeframe:
            if timeframe not in TIMEFRAME_SECONDS: return []
            rows=list(self.history[symbol][timeframe])
            if include_current and self.candles[symbol].get(timeframe): rows.append(self.candles[symbol][timeframe].copy())
            return rows
        return {tf:self.snapshot(symbol,tf,include_current) for tf in TIMEFRAME_SECONDS}

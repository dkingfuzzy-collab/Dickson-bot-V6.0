from statistics import mean

def _swing_high(b, i, n=2):
    return all(b[i]["high"] >= b[j]["high"] for j in range(i-n, i+n+1) if j != i)

def _swing_low(b, i, n=2):
    return all(b[i]["low"] <= b[j]["low"] for j in range(i-n, i+n+1) if j != i)

def structure(bars):
    if len(bars) < 10: return {"state":"INSUFFICIENT"}
    highs=[b["high"] for b in bars[-20:]]
    lows=[b["low"] for b in bars[-20:]]
    return {"state":"BULLISH" if highs[-1] > highs[0] and lows[-1] >= lows[0] else
            "BEARISH" if highs[-1] < highs[0] and lows[-1] <= lows[0] else "NEUTRAL"}

def liquidity_sweep(bars):
    if len(bars) < 8: return {"bullish":False,"bearish":False}
    x=bars[-1]; prior=bars[-7:-1]
    ph=max(v["high"] for v in prior); pl=min(v["low"] for v in prior)
    return {
        "bullish": x["low"] < pl and x["close"] > pl,
        "bearish": x["high"] > ph and x["close"] < ph
    }

def displacement(bars):
    if len(bars) < 10: return {"bullish":False,"bearish":False}
    x=bars[-1]
    rng=x["high"]-x["low"]
    avg=mean(v["high"]-v["low"] for v in bars[-10:-1])
    body=abs(x["close"]-x["open"])
    strong = avg > 0 and body >= 1.3*avg and rng > 0
    return {"bullish": strong and x["close"]>x["open"],
            "bearish": strong and x["close"]<x["open"]}

def fvg(bars):
    if len(bars) < 3: return {"bullish":False,"bearish":False}
    a,b,c=bars[-3],bars[-2],bars[-1]
    return {"bullish": c["low"] > a["high"], "bearish": c["high"] < a["low"]}

def analyze(symbol, bars):
    if not bars:
        return {"symbol":symbol,"status":"waiting_for_market_data","mode":"paper_only"}
    s=structure(bars); sweep=liquidity_sweep(bars)
    disp=displacement(bars); gap=fvg(bars)
    bull = sweep["bullish"] and disp["bullish"] and gap["bullish"]
    bear = sweep["bearish"] and disp["bearish"] and gap["bearish"]
    score=sum([s["state"]=="BULLISH",sweep["bullish"],disp["bullish"],gap["bullish"]]) if bull else \
          sum([s["state"]=="BEARISH",sweep["bearish"],disp["bearish"],gap["bearish"]]) if bear else 0
    return {
        "symbol":symbol,"mode":"paper_only","structure":s,"liquidity_sweep":sweep,
        "displacement":disp,"fvg":gap,
        "signal":"BUY_PAPER" if bull else "SELL_PAPER" if bear else "NO_SETUP",
        "confluence_score":score,
        "note":"Prototype ICT/SMC detector; validate with historical data before relying on signals."
    }

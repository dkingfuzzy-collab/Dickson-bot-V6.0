# Dickson Bot V6.3 — Live Feed + Paper Analysis

This version adds provider adapters for real-time market data while keeping the strategy strictly paper/simulation only.

## Supported feed paths

### BTC/USDT
A public Binance market-data WebSocket adapter is included. It receives trade-price updates and does not require account credentials.

### FX / commodities
A Twelve Data WebSocket adapter is included for symbols such as `EUR/USD` and `XAU/USD`. Set `TWELVE_DATA_API_KEY` in your environment.

The provider layer only supplies market data. It does not place orders.

## Important
The current ICT/SMC detector is still a prototype. Live prices are not evidence that a signal is profitable. Historical validation and paper-trading observation should come before treating any signal as reliable.


V7.4 adds the multi-bot confluence dashboard: Structure, Liquidity Sweep, FVG, Displacement, and ICT/SMC Context results are shown individually alongside the combined direction, score, alignment count, qualification state, and POI context. The terminal remains paper/research only.

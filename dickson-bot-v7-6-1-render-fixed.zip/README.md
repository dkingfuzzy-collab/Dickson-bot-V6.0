# Dickson Trading Terminal V7.6.1

Paper/research terminal only. No live order execution.

## Data feed
- BTCUSD is bootstrapped from public Binance historical candles and then updated from the public BTC/USDT trade stream.
- Dashboard symbol aliases normalize BTCUSD/BTCUSDT/BTC-USDT to BTCUSD.
- 1m, 15m, 1h, 4h and 1d candles are maintained.
- `AUTO_START_FEEDS=true` starts the feed automatically.
- Optional Twelve Data support can provide XAU/USD, EUR/USD and GBP/USD when `TWELVE_DATA_API_KEY` is configured.

## Render
Build: `python -c "import zipfile; zipfile.ZipFile('dickson-bot-v7-6-1-paper-feed.zip').extractall('app')" && pip install -r app/requirements.txt`
Start: `cd app && uvicorn main:app --host 0.0.0.0 --port $PORT`

# V7.6 Deployment

## Local
1. Copy `config/settings.example.env` to `.env` and set a long random `ADMIN_PASSWORD`.
2. Set `COOKIE_SECURE=false` for plain localhost HTTP testing. Use `true` behind HTTPS.
3. Install dependencies: `python -m pip install -r backend/requirements.txt`.
4. Start: `cd backend && python -m uvicorn main:app --host 127.0.0.1 --port 8000`.
5. Open `http://127.0.0.1:8000/` after serving the frontend from the same host, or configure a reverse proxy.

## Docker
1. Copy `config/settings.example.env` to `.env` and set secrets.
2. `docker compose up -d --build`.
3. Put an HTTPS reverse proxy in front of the container for public deployment.

## Production checklist
- Use HTTPS.
- Set `COOKIE_SECURE=true`.
- Set a strong unique `ADMIN_PASSWORD` and do not commit `.env`.
- Set `ALLOWED_ORIGINS` to the exact terminal origin(s), not `*`.
- Persist `backend/data`.
- Keep `MODE=paper_only`.
- Do not expose the SQLite database publicly.

import os, sys
BASE=os.path.dirname(__file__)
sys.path.insert(0, os.path.join(BASE, 'backend'))
from main import app
